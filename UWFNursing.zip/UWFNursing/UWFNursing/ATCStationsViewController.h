//
//  ATCViewController.h
//  UWFNursing
//
//  Created by Janusz Chudzynski on 7/29/14.
//  Copyright (c) 2014 Janusz Chudzynski. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  main view controller that displays menu of the application
 */
@interface ATCStationsViewController : UIViewController

@end
