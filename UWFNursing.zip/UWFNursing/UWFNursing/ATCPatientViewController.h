//
//  ATCPatientViewController.h
//  UWFNursing
//
//  Created by Janusz Chudzynski on 10/31/14.
//  Copyright (c) 2014 Janusz Chudzynski. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ATCPatient;
@interface ATCPatientViewController : UIViewController
@property  (nonatomic,strong)ATCPatient * patient;


@end
