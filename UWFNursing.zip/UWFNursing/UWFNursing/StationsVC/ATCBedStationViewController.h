//
//  ATCBedStationViewController.h
//  UWFNursing
//
//  Created by Janusz Chudzynski on 10/31/14.
//  Copyright (c) 2014 Janusz Chudzynski. All rights reserved.
//

#import <UIKit/UIKit.h>
/**Will be used to display a patient's bed and information about them */
@interface ATCBedStationViewController : UIViewController
@property(nonatomic,strong)id station;

@end
