//
//  ATCAuthenticateViewController.h
//  UWFNursing
//
//  Created by Janusz Chudzynski on 9/29/14.
//  Copyright (c) 2014 Janusz Chudzynski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ATCAuthenticateViewController : UIViewController

@end
