//
//  ATCWarningViewController.h
//  UWFNursing
//
//  Created by Janusz Chudzynski on 10/13/14.
//  Copyright (c) 2014 Janusz Chudzynski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ATCWarningViewController : UIViewController

@end
