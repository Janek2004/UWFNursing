//
//  ATCWashingHandsStationViewController.h
//  UWFNursing
//
//  Created by Janusz Chudzynski on 9/15/14.
//  Copyright (c) 2014 Janusz Chudzynski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ATCWashingHandsStationViewController : UIViewController

@end
