//
//  ATCLogViewController.h
//  UWFNursing
//
//  Created by Janusz Chudzynski on 8/8/14.
//  Copyright (c) 2014 Janusz Chudzynski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ATCLogViewController : UIViewController

@end
