UWFNursing
==========

iOS Client for UWF Nursing System
App is used with conjunction to Beacons to:
- monitor washing hands stations
- scan wristbands of the patients
- access documents related to the lab
